delimiter //
create procedure 7goodsciencefiction(in somename varchar(50))
begin
select title from movies where userrating > 8 and genre= "science fiction";
end //
delimiter ;