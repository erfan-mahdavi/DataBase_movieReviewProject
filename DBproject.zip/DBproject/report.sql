DELIMITER $$

CREATE PROCEDURE report(IN p_username VARCHAR(50))
BEGIN
    DECLARE v_userID INT;

    -- Get the userID based on the username
    SELECT userID INTO v_userID FROM users WHERE username = p_username;

    -- Check if user exists
    IF v_userID IS NULL THEN
        SELECT 'User not found' AS message;
    ELSE
        -- Insert the report into the user_yearly_report table
        INSERT INTO user_yearly_report (
            userID, 
            movies_watched,
            comments_made,
            favorite_genre,
            top_actors,
            total_sales,
            average_rating,
            most_rated_movie,
            month_most_movies_watched,
            most_popular_playlist,
            favorite_watchlist,
            total_watchlists,
            avg_sales_amount,
            total_movies_in_watchlists,
            report_year
        )
        SELECT 
            v_userID, 

            -- 1. Number of movies watched by the user
            (SELECT COUNT(DISTINCT w.movieID) 
             FROM watched w
             WHERE w.userID = v_userID AND YEAR(w.watchedmoviedate) = YEAR(CURDATE())),

            -- 2. Number of comments made by the user
            (SELECT COUNT(c.commentID) 
             FROM comments c
             WHERE c.userID = v_userID AND YEAR(c.commentdate) = YEAR(CURDATE())),

            -- 3. Favorite genre of the user (most watched genre)
            (SELECT m.genre
             FROM watched w
             JOIN movies m ON w.movieID = m.movieID
             WHERE w.userID = v_userID AND YEAR(w.watchedmoviedate) = YEAR(CURDATE())
             GROUP BY m.genre
             ORDER BY COUNT(w.movieID) DESC
             LIMIT 1),

            -- 4. Actors seen the most by the user (Group and select top 5)
            (SELECT a.actorname
             FROM movieactors ma
             natural JOIN actors a
             natural JOIN watched w
             WHERE w.userID = v_userID AND YEAR(w.watchedmoviedate) = YEAR(CURDATE())
             GROUP BY a.actorID
             ORDER BY COUNT(a.actorID) DESC
             LIMIT 1),

            -- 5. average sales of movies watched by the user
            (SELECT avg(m.salesamount)
             FROM watched w
             JOIN movies m ON w.movieID = m.movieID
             WHERE w.userID = v_userID AND YEAR(w.watchedmoviedate) = YEAR(CURDATE())),

            -- 6. Average rating given by the user
            (SELECT AVG(c.userrating)
             FROM comments c
             WHERE c.userID = v_userID AND YEAR(c.commentdate) = YEAR(CURDATE())),

            -- 7. movie with highest userrating
            (SELECT m.title
             FROM comments c
             natural join movies m
             WHERE YEAR(c.commentdate) = YEAR(CURDATE())
             order by userrating desc limit 1),

            -- 8. Month in which the user watched the most movies
            (SELECT MONTH(w.watchedmoviedate)
             FROM watched w
             WHERE w.userID = v_userID AND YEAR(w.watchedmoviedate) = YEAR(CURDATE())
             GROUP BY MONTH(w.watchedmoviedate)
             ORDER BY COUNT(w.movieID) DESC
             LIMIT 1),

            -- 9. Most popular playlist of the user (most added to watchlists)
            (SELECT wl.watchlistname
             FROM watchlists wl
             JOIN watchlistmovies wm ON wl.watchlistID = wm.watchlistID
             WHERE wl.userID = v_userID
             GROUP BY wl.watchlistname
             ORDER BY COUNT(wm.movieID) DESC
             LIMIT 1),

            -- 10. Favorite watchlist (the one with the most movies added)
            (SELECT wl.watchlistname
             FROM watchlists wl
             JOIN watchlistmovies wm ON wl.watchlistID = wm.watchlistID
             WHERE wl.userID = v_userID
             GROUP BY wl.watchlistname
             ORDER BY COUNT(wm.movieID) DESC
             LIMIT 1),

            -- 11. Total number of watchlists created by the user
            (SELECT COUNT(wl.watchlistID)
             FROM watchlists wl
             WHERE wl.userID = v_userID),

            -- 12. Average sales of movies watched by the user
            (SELECT AVG(m.salesamount)
             FROM watched w
             JOIN movies m ON w.movieID = m.movieID
             WHERE w.userID = v_userID AND YEAR(w.watchedmoviedate) = YEAR(CURDATE())),

            -- 13. Total number of movies in the user's watchlist
            (SELECT COUNT(wm.movieID)
             FROM watchlistmovies wm
             JOIN watchlists wl ON wm.watchlistID = wl.watchlistID
             WHERE wl.userID = v_userID),

            -- 14. Report year
            YEAR(CURDATE());
    END IF;
END$$

DELIMITER ;