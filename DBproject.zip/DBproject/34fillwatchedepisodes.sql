DELIMITER $$  

CREATE PROCEDURE 34fillwatchedepisodes()  
BEGIN  
    DECLARE i INT DEFAULT 0;  
    DECLARE max_series_id INT DEFAULT 100;  -- assuming you have 100 series  
    DECLARE max_episode_number INT DEFAULT 100;  -- assuming each series has 100 episodes  

    WHILE i < 10000 DO  
        INSERT INTO watchedepisodes (seriesID, watchedepisodenumber, wathedepisodedate)  
        VALUES (  
            FLOOR(1 + RAND() * max_series_id),  -- Random seriesID between [1, max_series_id]  
            FLOOR(1 + RAND() * max_episode_number),  -- Random episode number between [1, max_episode_number]  
            CURDATE() - INTERVAL (FLOOR(RAND() * 365)) DAY  -- Random date in the last year  
        );  
        SET i = i + 1;  
    END WHILE;  
END $$  

DELIMITER ;