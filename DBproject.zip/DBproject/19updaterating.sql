DELIMITER //  

CREATE PROCEDURE 19updaterating(IN num DECIMAL(3,2), IN someid INT)  
BEGIN  
    UPDATE movies  
    SET websiterating = num  
    WHERE movieID = someid;  
END //  

DELIMITER ;