DELIMITER //  

CREATE PROCEDURE 16genresales()  
BEGIN  
select sum(salesamount) as total_genre_sale , genre from movies group by genre;
END //  

DELIMITER ;