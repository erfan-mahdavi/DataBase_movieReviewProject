DELIMITER //  

CREATE PROCEDURE 20fillmovies()  
BEGIN  
    DECLARE v_counter INT DEFAULT 0;  

    WHILE v_counter < 10000 DO  
        INSERT INTO movies (title, genre, company, director, salesamount, releasedate, websiterating, userrating)   
        VALUES (  
            CONCAT('Movie ', v_counter + 1),  -- Generating a unique title  
            ELT(FLOOR(1 + (RAND() * 5)), 'Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi'),  -- Random genre  
            ELT(FLOOR(1 + (RAND() * 5)), 'Company A', 'Company B', 'Company C', 'Company D', 'Company E'),  -- Random company  
            CONCAT('Director ', FLOOR(1 + (RAND() * 20))),  -- Random director, up to 20 directors  
            ROUND(RAND() * 1000000, 2),  -- Sales amount, random between 0 and 1,000,000.00  
            DATE_ADD('2000-01-01', INTERVAL FLOOR(RAND() * 7300) DAY),  -- Random date within ~20 years  
            ROUND(RAND() * 10, 2),  -- Random websiterating between 0 and 10  
            ROUND(RAND() * 10, 2)   -- Random userrating between 0 and 10  
        );  

        SET v_counter = v_counter + 1;  
    END WHILE;  
END //  

DELIMITER ;