delimiter //
create procedure 29secondone()
begin
-- Query to find the top 3 actors with the highest total sales amount
SELECT 
    a.actorname,
    SUM(m.salesamount) AS total_sales
FROM 
    actors a
JOIN 
    movieactors ma ON a.actorID = ma.actorID
JOIN 
    movies m ON ma.movieID = m.movieID
GROUP BY 
    a.actorname
ORDER BY 
    total_sales DESC
LIMIT 3;

end //
delimiter ;