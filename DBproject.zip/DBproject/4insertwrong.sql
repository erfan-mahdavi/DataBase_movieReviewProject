DELIMITER //
CREATE PROCEDURE 4insertwrong()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        -- Rollback changes in case of an error
        ROLLBACK;
    END;

    -- Start a transaction
    START TRANSACTION;

    -- Insert logically invalid but constraint-satisfying values into each table
    INSERT INTO movies (movieID,title, genre, company, director, salesamount, releasedate, websiterating, userrating)
    VALUES (999,'Unknown Movie', 'unknown genre', 'Unknown Studio', 'Unknown Director', 999999999.00, '1900-01-01', 0.0, 0.0);

    INSERT INTO actors (actorname, actorage, actorbiography)
    VALUES ('Unknown Actor', 999, 'Biography not available.');

    INSERT INTO movieactors (movieID, actorID, actorpay)
    VALUES (999, 999, 999999.00);

    INSERT INTO seriesepisodes (seriesID, episodenumber)
    VALUES (999, 999);

    INSERT INTO users (username, userpassword, useremail, userage)
    VALUES ('unknown_user', 999999999, 'unknown@unknown.com', 999);

    INSERT INTO comments (userID, movieID, userrating, commenttext, commentdate)
    VALUES (999, 999, 0.0, 'This is an invalid comment.', '1900-01-01');

    INSERT INTO watched (userID, movieID, watchedmoviedate)
    VALUES (999, 999, '1900-01-01');

    INSERT INTO watchedepisodes (seriesID, watchedepisodenumber, wathedepisodedate)
    VALUES (999, 999, '1900-01-01');

    INSERT INTO watchlists (userID, watchlistname, public, creationdate)
    VALUES (999, 'Invalid Watchlist', 0, '1900-01-01');

    INSERT INTO watchlistmovies (watchlistID, movieID)
    VALUES (999, 999);

    INSERT INTO watchlistseries (watchlistID, seriesID, episodenumber)
    VALUES (999, 999, 999);

    -- Correct the inserted "unknown" values
    UPDATE movies SET title = 'Corrected Movie', genre = 'Drama', company = 'Corrected Studio', director = 'Corrected Director'
    WHERE title = 'Unknown Movie';

    UPDATE actors SET actorname = 'Corrected Actor', actorage = 40, actorbiography = 'Biography updated.'
    WHERE actorname = 'Unknown Actor';

    UPDATE movieactors SET movieID = 1, actorID = 1, actorpay = 5000000.00
    WHERE movieID = 999 AND actorID = 999;

    UPDATE seriesepisodes SET seriesID = 1, episodenumber = 1
    WHERE seriesID = 999 AND episodenumber = 999;

    UPDATE users SET username = 'corrected_user', userpassword = 123456, useremail = 'corrected@example.com', userage = 25
    WHERE username = 'unknown_user';

    UPDATE comments SET userID = 1, movieID = 1, userrating = 8.5, commenttext = 'Updated comment.', commentdate = '2025-01-20'
    WHERE userID = 999 AND movieID = 999;

    UPDATE watched SET userID = 1, movieID = 1, watchedmoviedate = '2025-01-25'
    WHERE userID = 999 AND movieID = 999;

    UPDATE watchedepisodes SET seriesID = 1, watchedepisodenumber = 1, wathedepisodedate = '2025-01-25'
    WHERE seriesID = 999 AND watchedepisodenumber = 999;

    UPDATE watchlists SET userID = 1, watchlistname = 'Corrected Watchlist', public = 1, creationdate = '2025-01-25'
    WHERE watchlistname = 'Invalid Watchlist';

    UPDATE watchlistmovies SET watchlistID = 1, movieID = 1
    WHERE watchlistID = 999 AND movieID = 999;

    UPDATE watchlistseries SET watchlistID = 1, seriesID = 1, episodenumber = 1
    WHERE watchlistID = 999 AND seriesID = 999 AND episodenumber = 999;

    -- Rollback the transaction to undo all changes
    ROLLBACK;
END;
//
DELIMITER ;
