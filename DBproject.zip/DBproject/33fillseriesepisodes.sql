DELIMITER $$  

CREATE PROCEDURE 33fillseriesepisodes()  
BEGIN  
    DECLARE series_id INT DEFAULT 1;  
    DECLARE episode_number INT DEFAULT 1;  
    DECLARE max_series INT DEFAULT 100;  -- number of series  
    DECLARE max_episodes_per_series INT DEFAULT 100;  -- number of episodes per series  

    WHILE series_id <= max_series DO  
        SET episode_number = 1;  -- Reset episode number for new series  

        WHILE episode_number <= max_episodes_per_series DO  
            INSERT INTO seriesepisodes (seriesID, episodenumber)  
            VALUES (series_id, episode_number);  
            SET episode_number = episode_number + 1;  
        END WHILE;  

        SET series_id = series_id + 1;  -- Move to the next series  
    END WHILE;  
END $$  

DELIMITER ;