delimiter //
create procedure 13recentlyadded()
begin
select title,addingdate,watchlistname from watchlists natural join watchlistmovies natural join movies where watchlistname = "future download" and 
addingdate >= NOW() - INTERVAL 30 DAY;
end //
delimiter ;