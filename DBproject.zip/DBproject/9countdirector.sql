delimiter //
create procedure 9countdirector()
begin
select director,count(director) from movies group by director having count(director) > 3;
end //
delimiter ;