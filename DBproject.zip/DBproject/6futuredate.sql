delimiter //
create procedure 6futuredate(in somename varchar(50))
begin
select * from users natural join watchlists natural join watchlistmovies where watchlistname = "future download" ;
end //
delimiter ;