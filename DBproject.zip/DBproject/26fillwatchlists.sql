DELIMITER //  

CREATE PROCEDURE 26fillwatchlists()  
BEGIN  
    DECLARE v_counter INT DEFAULT 0;  
    DECLARE v_userID INT;  
    DECLARE v_watchlistname VARCHAR(50);  
    DECLARE v_public INT;  
    DECLARE v_creationdate DATE;  

    -- Get the count of users for random selection  
    DECLARE v_user_count INT;  

    -- Retrieve total count of users  
    SELECT COUNT(*) INTO v_user_count FROM users;  

    WHILE v_counter < 10000 DO  
        -- Randomly select userID from existing users  
        SET v_userID = FLOOR(1 + (RAND() * v_user_count));  

        -- Generate a random watchlist name  
        SET v_watchlistname = CONCAT('Watchlist ', v_counter + 1);  -- E.g., "Watchlist 1", "Watchlist 2", etc.  

        -- Randomly determine if the watchlist is public (0 or 1)  
        SET v_public = FLOOR(RAND() * 2);  -- Generates either 0 or 1  

        -- Generate a random creation date (within the last 365 days)  
        SET v_creationdate = DATE_ADD(CURRENT_DATE, INTERVAL FLOOR(RAND() * -365) DAY);  -- Random date in the last year  

        -- Insert the record into the watchlists table  
        INSERT INTO watchlists (userID, watchlistname, public, creationdate)  
        VALUES (  
            v_userID,  
            v_watchlistname,  
            v_public,  
            v_creationdate  
        );  

        SET v_counter = v_counter + 1;  -- Increment the counter  
    END WHILE;  
END //  

DELIMITER ;