DELIMITER //  

CREATE PROCEDURE fillcomments()  
BEGIN  
    DECLARE v_counter INT DEFAULT 0;  
    DECLARE v_userID INT;  
    DECLARE v_movieID INT;  
    DECLARE v_userrating DECIMAL(4,2);  
    DECLARE v_commenttext VARCHAR(200);  
    DECLARE v_commentdate DATE;  

    -- Get the count of users and movies for random selection  
    DECLARE v_user_count INT;  
    DECLARE v_movie_count INT;  

    -- Get the total number of users  
    SELECT COUNT(*) INTO v_user_count FROM users;  
    
    -- Get the total number of movies  
    SELECT COUNT(*) INTO v_movie_count FROM movies;  

    WHILE v_counter < 10000 DO  
        -- Randomly select userID and movieID  
        SET v_userID = FLOOR(1 + (RAND() * v_user_count));  
        SET v_movieID = FLOOR(1 + (RAND() * v_movie_count));  

        -- Generate a random user rating between 0 and 10  
        SET v_userrating = ROUND(RAND() * 10, 2);  

        -- Generate a random comment text; here we will use a simple template  
        SET v_commenttext = CONCAT('This is a comment for movie ', v_movieID, ' by user ', v_userID, '. Rating: ', v_userrating);  

        -- Generate a random comment date (You might want to adjust the date range as needed)  
        SET v_commentdate = DATE_ADD(CURRENT_DATE, INTERVAL FLOOR(RAND() * -30) DAY);  -- Random date within last 30 days  

        -- Insert the comment record into the comments table  
        INSERT INTO comments (userID, movieID, userrating, commenttext, commentdate)  
        VALUES (  
            v_userID,  
            v_movieID,  
            v_userrating,  
            v_commenttext,  
            v_commentdate  
        );  

        SET v_counter = v_counter + 1;  -- Increment the counter  
    END WHILE;  
END //  

DELIMITER ;