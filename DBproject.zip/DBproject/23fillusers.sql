DELIMITER //  

CREATE PROCEDURE 23fillusers()  
BEGIN  
    DECLARE v_counter INT DEFAULT 0;  
    DECLARE v_username VARCHAR(50);  
    DECLARE v_userpassword NUMERIC(10);  
    DECLARE v_useremail VARCHAR(50);  
    DECLARE v_userage INT;  

    WHILE v_counter < 10000 DO  
        -- Generate a unique username   
        SET v_username = CONCAT('user', v_counter + 1);  -- Unique usernames like user1, user2, etc.  

        -- Generate a 10-digit numeric password  
        SET v_userpassword = FLOOR(1000000000 + (RAND() * 9000000000));  -- A number between 10-digit limits  

        -- Generate a unique email  
        SET v_useremail = CONCAT('user', v_counter + 1, '@example.com');  -- Unique email like user1@example.com  

        -- Generate a random age between 12 and 150  
        SET v_userage = FLOOR(12 + (RAND() * (150 - 12 + 1)));  -- Random age within bounds  

        -- Insert the user record into the users table  
        INSERT INTO users (username, userpassword, useremail, userage)  
        VALUES (  
            v_username,  
            v_userpassword,  
            v_useremail,  
            v_userage  
        );  

        SET v_counter = v_counter + 1;  -- Increment the counter  
    END WHILE;  
END //  

DELIMITER ;