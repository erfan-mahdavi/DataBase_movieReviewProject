CREATE DEFINER=`root`@`localhost` PROCEDURE `5moviecomment`(in somename varchar(50))
begin

with m(movieID,userrating,commenttext) as(select watched.movieID,userrating,commenttext from users join watched on users.userID = watched.userID  join comments 
on watched.userID = comments.userID where users.username= somename)
select * from m join movies on m.movieID = movies.movieID;
end