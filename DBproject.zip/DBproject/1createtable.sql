delimiter //
create procedure 1createtable()
BEGIN  
    START TRANSACTION;  

    -- Movies table with all constraints  
    CREATE TABLE IF NOT EXISTS movies (  
        movieID INT AUTO_INCREMENT PRIMARY KEY,  
        title VARCHAR(30) NOT NULL , 
        genre varchar(50),
        company VARCHAR(30),  
        director VARCHAR(30),  
        salesamount NUMERIC(12,2) CHECK (salesamount >= 0), -- Ensure salesamount is non-negative  
        releasedate DATE,  
        websiterating DECIMAL(4,2) CHECK (websiterating BETWEEN 0 AND 10),  
        userrating DECIMAL(4,2) CHECK (userrating BETWEEN 0 AND 10)  
    );  

    -- Actors table with age constraint  
    CREATE TABLE IF NOT EXISTS actors (  
        actorID INT PRIMARY KEY,  
        actorname VARCHAR(50) NOT NULL,  
        actorage INT CHECK (actorage BETWEEN 3 AND 150),  
        actorbiography VARCHAR(100)  
    );  

    -- Movie actors table  
    CREATE TABLE IF NOT EXISTS movieactors (  
        movieactorID INT AUTO_INCREMENT PRIMARY KEY,  
        movieID INT NOT NULL,  
        actorID INT NOT NULL,  
        actorpay NUMERIC(10,2) CHECK (actorpay >= 0), -- Ensure actor pay is non-negative  
        CONSTRAINT unique_movie_actor UNIQUE (movieID, actorID) -- Ensure unique pairing  
    );  

    -- Series episodes table  
    CREATE TABLE IF NOT EXISTS seriesepisodes (  
        seriesepisodeID INT AUTO_INCREMENT PRIMARY KEY,  
        seriesID INT NOT NULL,  
        episodenumber INT NOT NULL,  
        CONSTRAINT unique_seriesepisode UNIQUE (seriesID, episodenumber) -- Ensure unique episodes in a series  
    );  

    -- Users table with validation constraints  
    CREATE TABLE IF NOT EXISTS users (  
        userID INT AUTO_INCREMENT PRIMARY KEY,  
        username VARCHAR(50) NOT NULL UNIQUE,  
        userpassword NUMERIC(10) NOT NULL CHECK (LENGTH(CAST(userpassword AS CHAR)) = 10), -- Password length check  
        useremail VARCHAR(50) NOT NULL UNIQUE,  
        userage INT NOT NULL CHECK (userage BETWEEN 12 AND 150) -- Age should be between 12 and 150  
    );  

    -- Comments table with rating validation  
    CREATE TABLE IF NOT EXISTS comments (  
        commentID INT AUTO_INCREMENT PRIMARY KEY,  
        userID INT NOT NULL,  
        movieID INT NOT NULL,  
        userrating DECIMAL(4,2) NOT NULL CHECK (userrating BETWEEN 0 AND 10), -- User rating check  
        commenttext VARCHAR(200) NOT NULL, -- Make comment text mandatory  
        commentdate DATE NOT NULL -- Make comment date mandatory  
         );  

    -- Watched table with viewing constraints  
    CREATE TABLE IF NOT EXISTS watched (  
        watchedID INT AUTO_INCREMENT PRIMARY KEY,  
        userID INT NOT NULL,  
        movieID INT NOT NULL,  
        watchedmoviedate DATE NOT NULL -- Make watching date mandatory  
    );  

    -- Watched episodes table  
    CREATE TABLE IF NOT EXISTS watchedepisodes (  
        watchedepisodeID INT AUTO_INCREMENT PRIMARY KEY,  
        seriesID INT NOT NULL,  
        watchedepisodenumber INT NOT NULL,  
        wathedepisodedate date
    );  

    -- Watchlists table with privacy control  
    CREATE TABLE IF NOT EXISTS watchlists (  
        watchlistID INT AUTO_INCREMENT PRIMARY KEY,  
        userID INT NOT NULL,  
        watchlistname VARCHAR(50) NOT NULL, -- Make watchlist name mandatory  
        public INT NOT NULL CHECK (public IN (0, 1)), -- Public check (0 or 1)  
        creationdate DATE NOT NULL -- Make creation date mandatory  
    );  

    -- Watchlist movies mapping  
    CREATE TABLE IF NOT EXISTS watchlistmovies (  
        watchlistmoviesID INT AUTO_INCREMENT PRIMARY KEY,  
        watchlistID INT NOT NULL,  
        movieID INT NOT NULL,  
        addingdate date,
        CONSTRAINT unique_watchlist_movie UNIQUE (watchlistID, movieID) -- Ensure movie uniqueness in watchlist  
    );  

    -- Watchlist series mapping  
    CREATE TABLE IF NOT EXISTS watchlistseries (  
        watchlistseriesID INT AUTO_INCREMENT PRIMARY KEY,  
        watchlistID INT NOT NULL,  
        seriesID INT NOT NULL,  
        episodenumber INT NOT NULL, 
        addingdate date,
        CONSTRAINT unique_watchlist_series UNIQUE (watchlistID, seriesID, episodenumber) -- Ensure unique entries  
    );  

    COMMIT;  

END //
delimiter ;