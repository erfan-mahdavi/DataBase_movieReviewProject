delimiter //
create procedure 28firstone()
begin
select actorname,avg(userrating),genre from actors natural join movieactors natural join movies group by actorname,genre;
end //
delimiter ;