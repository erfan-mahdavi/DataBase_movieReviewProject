DELIMITER //  

CREATE PROCEDURE 22fillmovieactors()  
BEGIN  
    DECLARE v_counter INT DEFAULT 0;  
    DECLARE v_movieID INT;  
    DECLARE v_actorID INT;  

    -- Get the count of movies and actors for random selection  
    DECLARE v_movie_count INT;  
    DECLARE v_actor_count INT;  

    -- Get the total number of movies  
    SELECT COUNT(*) INTO v_movie_count FROM movies;  
    
    -- Get the total number of actors  
    SELECT COUNT(*) INTO v_actor_count FROM actors;  

    WHILE v_counter < 10000 DO  
        -- Randomly select a movieID and actorID  
        SET v_movieID = FLOOR(1 + (RAND() * v_movie_count));  
        SET v_actorID = FLOOR(1 + (RAND() * v_actor_count));  
        
        INSERT INTO movieactors (movieID, actorID, actorpay)  
        VALUES (  
            v_movieID,  -- Randomly selected movieID  
            v_actorID,  -- Randomly selected actorID  
            ROUND(RAND() * 100000, 2)  -- Random actor pay between 0 and 100,000  
        );  

        SET v_counter = v_counter + 1;  -- Increment the counter  
    END WHILE;  
END //  

DELIMITER ;