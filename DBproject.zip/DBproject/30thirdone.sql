DELIMITER $$

CREATE PROCEDURE 30thirdone()
BEGIN
    -- Variables to store averages
    DECLARE avg_christmas_sales NUMERIC(12,2);
    DECLARE avg_other_sales NUMERIC(12,2);
    DECLARE sales_difference NUMERIC(12,2);

    -- Calculate average salesamount for Christmas movies
    SELECT AVG(salesamount)
    INTO avg_christmas_sales
    FROM movies
    WHERE DAY(releasedate) = 25 AND MONTH(releasedate) = 12;

    -- Calculate average salesamount for non-Christmas movies
    SELECT AVG(salesamount)
    INTO avg_other_sales
    FROM movies
    WHERE NOT (DAY(releasedate) = 25 AND MONTH(releasedate) = 12);

    -- Calculate the difference between the two averages
    SET sales_difference = avg_christmas_sales - avg_other_sales;

    -- Output the results
    SELECT 
        avg_christmas_sales AS Christmas_Movies_Avg_Sales,
        avg_other_sales AS Other_Movies_Avg_Sales,
        sales_difference AS Sales_Difference;
END$$

DELIMITER ;
