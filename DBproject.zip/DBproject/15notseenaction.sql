delimiter //
create procedure 15notseenacction(in somename varchar(50))
BEGIN  
    -- Define the CTE a with a single column movieID  
    WITH a(movieID) AS (  
        SELECT movieID   
        FROM users   
        NATURAL JOIN watched  
        WHERE username = somename   
    )  
    -- Selecting titles of movies not seen by the given user  
    SELECT title   
    FROM movies   
    WHERE movieID NOT IN (SELECT movieID FROM a);  
END