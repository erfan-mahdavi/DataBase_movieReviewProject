delimiter //
CREATE PROCEDURE 31retentionrate()
BEGIN
WITH FirstPeriod AS (
    SELECT
        se.seriesID,
        m.title,
        AVG(c.userrating) AS avg_rating_first_15_days
    FROM
        seriesepisodes se
    JOIN
        movies m ON m.movieID = se.seriesID
    JOIN
        comments c ON c.movieID = m.movieID
    WHERE
        c.commentdate BETWEEN m.releasedate AND DATE_ADD(m.releasedate, INTERVAL 15 DAY)
    GROUP BY
        se.seriesID, m.title
),
RecentPeriod AS (
    SELECT
        se.seriesID,
        m.title,
        AVG(c.userrating) AS avg_rating_recent_15_days
    FROM
        seriesepisodes se
    JOIN
        movies m ON m.movieID = se.seriesID
    JOIN
        comments c ON c.movieID = m.movieID
    WHERE
        c.commentdate BETWEEN CURDATE() - INTERVAL 15 DAY AND CURDATE()
    GROUP BY
        se.seriesID, m.title
)
SELECT
    fp.seriesID,
    fp.title,
    fp.avg_rating_first_15_days,
    rp.avg_rating_recent_15_days
FROM
    FirstPeriod fp
JOIN
    RecentPeriod rp ON fp.seriesID = rp.seriesID
ORDER BY
    fp.seriesID;

END //
delimiter ;
