/*
drop procedure 1createtables;
drop procedure 2createforeignkeys;
drop procedure 3insertion
*/
-- drop database dbproject;
-- create database dbproject;
/*
SET SQL_SAFE_UPDATES = 0;
delete from movies;
delete from actors;
delete from movieactors;
*/
/*
delete from actors;
delete from movies;
delete from movieactors;
delete from users;
delete from comments;
delete from seriesepisodes;
delete from watched;
delete from watchedepisodes;
delete from watchlists;
delete from watchlistseries;
*/
/*
call 1createtable();
call 2createforeignkeys();
call 3insertion();
*/
/*
call 4insertwrong();
call 5moviecomment("neo");
call 6futuredate("neo");
call 7goodsciencefiction("science fiction");
call 8invalidrating();
call 9countdirector();
call 10hardworkingactor();
call 11countgenre();
call 12futuredownloadseen()
call 13recentlyadded();
call 14companydirector("The Wachowskis");
call 15notseenaction("neo");
call 16genresales();
call 17fiftycomments();
call 18actorswhoplay();
call 19updaterating(2.3,1);
*/
-- call 20fillmovies();
-- call 21fillactors();
-- call 22fillmovieactors();
-- call 23fillusers();
-- call 24fillcomments();
-- call 25fillwatched();
-- call 26fillwatchlists();
-- call 27fillwatchlistmovies()
-- call 34fillwatchedepisodes()

 -- call 31retentionrate()
-- call 32agegroup()

/*
call report("user10");
call report("user15");
call report("user100");
call report("user150");
call report("user151");
call report("user152");
call report("user159");
call report("user160");
 call report("user171");
 call report("user172");
 call report("user173");
 call report("user174");
 call report("user175");
 call report("user176");
 call report("user177");
 call report("user178");
 call report("user170");
select * from user_yearly_report
*/
