delimiter //
create procedure 10hardworkingactor()
begin
select actorname,count(actorname) from movieactors natural join actors group by actorname order by count(actorname) desc limit 3;
end //
delimiter ;