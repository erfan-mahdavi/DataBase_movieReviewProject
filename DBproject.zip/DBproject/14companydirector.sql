DELIMITER //  

CREATE PROCEDURE 14companydirector(IN somename VARCHAR(50))  
BEGIN  
    SELECT   
        COUNT(company) AS company_count,  
        company,  
        director   
    FROM   
        movies   
    WHERE   
        director = somename   
    GROUP BY   
        company, director  -- Include director in the GROUP BY to comply with SQL mode  
    HAVING   
        COUNT(company) > 1;  -- Only select companies with more than 1 entry  
END //  

DELIMITER ;