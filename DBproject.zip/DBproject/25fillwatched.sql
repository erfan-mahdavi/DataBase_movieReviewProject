DELIMITER //  

CREATE PROCEDURE 25fillwatched()  
BEGIN  
    DECLARE v_counter INT DEFAULT 0;  
    DECLARE v_userID INT;  
    DECLARE v_movieID INT;  
    DECLARE v_watchedmoviedate DATE;  

    -- Get the count of users and movies for random selection  
    DECLARE v_user_count INT;  
    DECLARE v_movie_count INT;  

    -- Retrieve total count of users  
    SELECT COUNT(*) INTO v_user_count FROM users;  
    
    -- Retrieve total count of movies  
    SELECT COUNT(*) INTO v_movie_count FROM movies;  

    WHILE v_counter < 10000 DO  
        -- Randomly select userID and movieID  
        SET v_userID = FLOOR(1 + (RAND() * v_user_count));  
        SET v_movieID = FLOOR(1 + (RAND() * v_movie_count));  

        -- Generate a random watched movie date (within the last year)  
        SET v_watchedmoviedate = DATE_ADD(CURRENT_DATE, INTERVAL FLOOR(RAND() * -365) DAY); -- Random date in the last year  

        -- Insert the record into the watched table  
        INSERT INTO watched (userID, movieID, watchedmoviedate)  
        VALUES (  
            v_userID,  
            v_movieID,  
            v_watchedmoviedate  
        );  

        SET v_counter = v_counter + 1;  -- Increment the counter  
    END WHILE;  
END //  

DELIMITER ;