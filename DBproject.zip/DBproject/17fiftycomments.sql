DELIMITER //  

CREATE PROCEDURE 17fiftycomments()  
BEGIN  
select title,count(userrating) from comments natural join movies where userrating >= 8 group by title having count(userrating) > 50;
END //  

DELIMITER ;