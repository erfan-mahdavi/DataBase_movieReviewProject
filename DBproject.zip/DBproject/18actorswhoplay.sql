DELIMITER //  

CREATE PROCEDURE 18actorswhoplay()  
BEGIN   -- i replaced drama with science fiction because we don't have any drama here
select actorname from actors natural join movieactors natural join movies where genre ="science fiction";
END //  

DELIMITER ;