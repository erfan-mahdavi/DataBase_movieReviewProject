delimiter //
create procedure 8invalidrating()
begin
select title from movies where userrating >10 or userrating <0;
end //
delimiter ;