delimiter //
create procedure 2createforeignkeys()
begin
-- Foreign key constraints (as before)

ALTER TABLE movieactors
ADD CONSTRAINT fk_movieactors_movie FOREIGN KEY (movieID) REFERENCES movies(movieID) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT fk_movieactors_actor FOREIGN KEY (actorID) REFERENCES actors(actorID) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE seriesepisodes
ADD CONSTRAINT fk_seriesepisodes_movie FOREIGN KEY (seriesID) REFERENCES movies(movieID) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE comments
ADD CONSTRAINT fk_comments_user FOREIGN KEY (userID) REFERENCES users(userID) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT fk_comments_movie FOREIGN KEY (movieID) REFERENCES movies(movieID) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE watched
ADD CONSTRAINT fk_watched_user FOREIGN KEY (userID) REFERENCES users(userID) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT fk_watched_movie FOREIGN KEY (movieID) REFERENCES movies(movieID) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE watchedepisodes
ADD CONSTRAINT fk_watchedepisodes_watched FOREIGN KEY (seriesID) REFERENCES watched(movieID) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT fk_watchedepisodes_series FOREIGN KEY (seriesID, watchedepisodenumber) REFERENCES seriesepisodes(seriesID, episodenumber) ON delete cascade on update cascade;

ALTER TABLE watchlists
ADD CONSTRAINT fk_watchlists_user FOREIGN KEY (userID) REFERENCES users(userID) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE watchlistmovies
ADD CONSTRAINT fk_watchlistmovies_watchlist FOREIGN KEY (watchlistID) REFERENCES watchlists(watchlistID) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT fk_watchlistmovies_movie FOREIGN KEY (movieID) REFERENCES movies(movieID) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE watchlistseries
ADD CONSTRAINT fk_watchlistseries_watchlist FOREIGN KEY (watchlistID) REFERENCES watchlists(watchlistID) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT fk_watchlistseries_series FOREIGN KEY (seriesID, episodenumber) REFERENCES seriesepisodes(seriesID, episodenumber) ON DELETE CASCADE ON UPDATE CASCADE;


end //
delimiter ;