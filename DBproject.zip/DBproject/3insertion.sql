-- Insert additional values into the tables

delimiter //
create procedure 3insertion()
begin
INSERT INTO movies (movieID,title,genre, company, director, salesamount, releasedate, websiterating, userrating)
VALUES
(1,'The Matrix',"science fiction", 'Warner Bros', 'The Wachowskis', 466364845.00, '1999-03-31', 9.0, 9.3),
(2,'sponge bob', "science fiction",'Warner Bros', 'The Wachowskis', 466364845.00, '1999-03-31', 9.9, 9.3),
(3,'better call saul',"science fiction", 'iran bros', 'The Wachowskis', 466364845.00, '2024-03-31', 3.2, 9.3),
(4,'movie 1', "science fiction",'iran bros', 'The Wachowskis', 466364845.00, '2024-03-31', 3.2, 9.3),
(5,'movie 2', "science fiction",'iran bros', 'The Wachowskis', 466364845.00, '2024-03-31', 3.2, 9.3),
(6,'movie 3', "science fiction",'iran bros', 'The Wachowskis', 466364845.00, '2024-03-31', 3.2, 9.3),
(7,'The Godfather', "science fiction",'Paramount', 'Francis Ford Coppola', 134966411.00, '1972-03-24', 9.8, 9.9);

INSERT INTO actors (actorID, actorname, actorage, actorbiography)
VALUES
(1,'mamad', 59, 'Known for action roles like Neo in The Matrix.'),
(2,'erfan', 59, 'Known for action roles like Neo in The Matrix.'),
(3,'Keanu Reeves', 59, 'Known for action roles like Neo in The Matrix.'),
(4,'Marlon Brando', 80, 'An iconic actor from The Godfather.'),
(5,'Invalid Actor', 100, 'Invalid age.'); 

INSERT INTO movieactors (movieID, actorID, actorpay)
VALUES
(2, 3, 15000000.00),
(2, 4, 12000000.00),
(1, 2, 8000000.00); 

INSERT INTO seriesepisodes (seriesID, episodenumber)
VALUES
(3, 1),
(3, 2),
(4,2),
(4,3),
(4, 1); 

INSERT INTO users (userID,username, userpassword, useremail, userage)
VALUES
(1,'neo', 1234567891, 'neo@example.com', 35),
(2,'godfather', 1234567891, 'godfkkather@example.com', 70),
(3,'user 5', 1234567891, 'godfatjher@example.com', 30),
(4,'user 2', 1234567891, 'godfagther@example.com', 30),
(5,'user 3', 1234567891, 'godfatwher@example.com', 30),
(6,'user 1', 1234567891, 'invalid@example.com', 15); 

INSERT INTO comments (userID, movieID, userrating, commenttext, commentdate)
VALUES
(1, 1, 9.5, 'Loved it!', '2025-01-10'),
(2, 2, 9, 'Too high rating!', '2025-01-11'),
(3, 4, 9, 'Too high rating!', '2025-01-11'); 

INSERT INTO watched (userID, movieID, watchedmoviedate)
VALUES
(1, 3, '2025-01-15'),
(2, 4, '2025-01-16'),
(2, 1, '2025-01-16'),
(3, 1, '2025-01-16');

INSERT INTO watchedepisodes (seriesID, watchedepisodenumber, wathedepisodedate)
VALUES
(3, 1, '2025-01-17'),
(3, 2, '2025-01-18'); 

INSERT INTO watchlists (userID, watchlistname, public, creationdate)
VALUES
(1, 'Action Classics', 1, '2025-01-20'),
(1, 'future download', 1, '2025-01-20'),
(2, 'future download', 1, '2025-01-20'),
(2, 'Drama Favorites', 0, '2025-01-21'); 

INSERT INTO watchlistmovies (watchlistID, movieID)
VALUES
(1, 3),
(2,3),
(1,2),
(2, 4);

INSERT INTO watchlistseries (watchlistID, seriesID, episodenumber)
VALUES
(2, 3, 1),
(2, 3, 2),
(2, 4, 1); 


end //
delimiter ;