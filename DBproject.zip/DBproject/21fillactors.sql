DELIMITER //  

CREATE PROCEDURE 21fillactors()  
BEGIN  
    DECLARE v_counter INT DEFAULT 1;  -- Start counter from 1 for actorID  

    WHILE v_counter <= 10000 DO  
        INSERT INTO actors (actorID, actorname, actorage, actorbiography)   
        VALUES (  
            v_counter,  -- Unique actorID  
            CONCAT('Actor ', v_counter),  -- Generating a unique actor name  
            FLOOR(3 + (RAND() * 148)),  -- Random age between 3 and 150  
            CONCAT('Biography of Actor ', v_counter, '. This actor is a fictional character used for demonstration purposes.')  -- Simple biography  
        );  

        SET v_counter = v_counter + 1;  -- Increment the counter  
    END WHILE;  
END //  

DELIMITER ;