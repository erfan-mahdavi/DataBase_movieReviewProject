DELIMITER //  

CREATE PROCEDURE 27fillwatchlistmovies()  
BEGIN  
    DECLARE v_counter INT DEFAULT 0;  
    DECLARE v_watchlistID INT;  
    DECLARE v_movieID INT;  
    DECLARE v_addingdate DATE;  

    -- Get the count of watchlists and movies for random selections  
    DECLARE v_watchlist_count INT;  
    DECLARE v_movie_count INT;  

    -- Retrieve total count of watchlists  
    SELECT COUNT(*) INTO v_watchlist_count FROM watchlists;  
    
    -- Retrieve total count of movies  
    SELECT COUNT(*) INTO v_movie_count FROM movies;  

    WHILE v_counter < 10000 DO  
        -- Randomly select watchlistID from existing watchlists  
        SET v_watchlistID = FLOOR(1 + (RAND() * v_watchlist_count));  

        -- Randomly select movieID from existing movies  
        SET v_movieID = FLOOR(1 + (RAND() * v_movie_count));  

        -- Generate a random adding date (within the last 90 days)  
        SET v_addingdate = DATE_ADD(CURRENT_DATE, INTERVAL FLOOR(RAND() * -90) DAY); -- Random date in the last 90 days  

        -- Insert the record into the watchlistmovies table  
        INSERT IGNORE INTO watchlistmovies (watchlistID, movieID, addingdate)  
        VALUES (  
            v_watchlistID,  
            v_movieID,  
            v_addingdate  
        );  

        SET v_counter = v_counter + 1;  -- Increment the counter  
    END WHILE;  
END //  

DELIMITER ;